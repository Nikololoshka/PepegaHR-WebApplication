from django.contrib import admin

from .models import Departament, HRUser


admin.site.register(Departament)
admin.site.register(HRUser)
