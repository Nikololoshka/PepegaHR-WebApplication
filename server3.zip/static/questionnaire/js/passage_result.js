$('.input-disable').on('click', function(e) {
    return false;
});