$(document).ready(function() {
    $('.modal').modal();
    $('.tooltipped').tooltip();
});